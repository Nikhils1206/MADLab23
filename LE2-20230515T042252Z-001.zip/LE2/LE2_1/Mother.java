class Mother {
    int x;
    void show(){
        System.out.println("Mother Function: show()");
    };
}