public class Application {
	public static void main (){
        Mother m=new Mother();
        m.show();
        Child ch=new Child ();
        ch.show ();
    }
}