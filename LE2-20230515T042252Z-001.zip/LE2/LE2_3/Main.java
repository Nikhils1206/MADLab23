class Main {
    public static void main(String[] args){
        Application A=new Application();
        A.main();
    }
}