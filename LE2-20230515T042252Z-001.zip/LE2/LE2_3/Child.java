class Child extends Mother {
    static void show(){
        System.out.println("Child Function: show()");//overriding 
    };
}