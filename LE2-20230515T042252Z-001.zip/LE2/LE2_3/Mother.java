class Mother {
    int x;
    static void show(){
        System.out.println("Mother Function: show()");//overriden function
    };
}