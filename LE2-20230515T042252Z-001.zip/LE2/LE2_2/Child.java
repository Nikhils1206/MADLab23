class Child extends Mother {
    void show(){
        System.out.println("Child Function: show()");
    };
}