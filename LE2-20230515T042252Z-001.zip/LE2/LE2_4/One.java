class One {
    One(){} // Parameterised constructor must be accompanied by a default constructor
    One(int x){} // Parameterised Constructor
}